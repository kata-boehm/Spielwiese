function sayHello() {
    alert("My name is Katharina!");
  }
  